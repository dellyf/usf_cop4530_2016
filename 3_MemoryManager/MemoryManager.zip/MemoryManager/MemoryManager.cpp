#include <cassert>
#include <iostream>
#include "dlUtils.h"
#include "MemoryManager.h"

MemoryManager::MemoryManager(unsigned int memtotal): memsize(memtotal)
{
   baseptr = new unsigned char[memsize];
   blockdata originalBlock(memsize,true,baseptr);
   firstBlock = new dlNode<blockdata>(originalBlock,nullptr,nullptr);
}

void MemoryManager::showBlockList() 
{
  printDlList(firstBlock,"->");
}

void MemoryManager::splitBlock(dlNode<blockdata> *p, unsigned int chunksize)
{ // Put your code below
  
}

unsigned char * MemoryManager::malloc(unsigned int request)
{ // Put your code below

}

void MemoryManager::mergeForward(dlNode<blockdata> *p)
{ // Put your code below

}

void MemoryManager::mergeBackward(dlNode<blockdata> *p)
{ // Put your code below

}

void MemoryManager::free(unsigned char *ptr2block)
{ // Put your code below

}


